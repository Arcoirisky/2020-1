Cada test tiene su input y el output corresponde a
ouptut_np.txt para non-preemptive
output_p_X.txt para preemptive con quantum X